desc = 'GPT4All API'

endpoint_paths = {'health': '/health'}
