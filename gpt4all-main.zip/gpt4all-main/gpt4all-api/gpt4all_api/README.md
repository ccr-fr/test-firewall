# FastAPI app for serving GPT4All models
