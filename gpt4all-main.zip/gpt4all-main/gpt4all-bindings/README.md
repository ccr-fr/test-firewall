# GPT4All Bindings
This directory will contain language specific bindings on top of the C/C++ model backends.
We will have one directory per language binding (e.g. Python, Typescript, Golang, etc.).