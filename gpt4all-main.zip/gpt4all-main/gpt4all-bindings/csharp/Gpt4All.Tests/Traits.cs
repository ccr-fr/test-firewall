﻿namespace Gpt4All.Tests;

public static class Traits
{
    public const string SkipOnCI = "SKIP_ON_CI";
}
