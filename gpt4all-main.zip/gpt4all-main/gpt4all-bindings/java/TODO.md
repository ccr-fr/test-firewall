## Needed
1. Integrate with circleci build pipeline like the C# binding.

## These are just ideas
1. Better Chat completions function.
2. Chat completion that returns result in OpenAI compatible format.
