# GPT4All Docker
This directory will contain Dockerfiles to build out different gpt4all recipes.

For example:
1. Docker container that builds out gpt4all RESTful API.
2. Docker container that builds out gpt4all model backends and Python bindings.
3. Docker container that builds out everything.
4. etc.